val x = 5;
var y = x
