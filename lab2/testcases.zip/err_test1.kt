fun main() {
    val bad = "this string never ends
    println("oops")
}