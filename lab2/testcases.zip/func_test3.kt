fun main() {
    var n : Int = 5

    if (n < 0) {
        println("{n} is negative")
    } else {
        println("{n} is zero")
    }
}