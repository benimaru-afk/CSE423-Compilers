fun main() {
    /* Level 1
       /* Level 2
          /* Level 3 */
       */
    */
    println("works")
}