fun main() {
    val s = "bad escape: \q"
    println(s)
}