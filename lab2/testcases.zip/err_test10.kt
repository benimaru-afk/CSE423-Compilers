fun main() {
    val s1 = "newline: \n"
    val s2 = "tab: \t"
    val s3 = "backslash: \\"
    val s4 = "quote: \""
    val s5 = "carriage return: \r"
    val s6 = "backspace: \b"
    val s7 = "form feed: \f"
    val s8 = "single quote: \'"
}