fun main() {
    val x = 12e
    println(x)
}