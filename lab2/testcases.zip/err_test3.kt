fun main() {
    val c = 'A
    println(c)
}