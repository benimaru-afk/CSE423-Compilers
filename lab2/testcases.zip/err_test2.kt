fun main() {
    /* This comment never closes
    val x = 5
}