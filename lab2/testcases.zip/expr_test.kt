z = 5 * 10
blazeIt = (n%5)*69+420
arr = 20/4+8