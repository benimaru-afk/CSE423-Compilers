fun main() {
    var x : Int = 5
    x + 1
}