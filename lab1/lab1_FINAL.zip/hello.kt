fun main(args : Array<String>) {
      println("Hello,\tWorld!")

      for (i in 1..10) {  // "for" is not in k0
        print(i)
    }
   }