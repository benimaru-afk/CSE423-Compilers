//Hello World in Kotlin

fun main() {
    println("Hello, World!")
}